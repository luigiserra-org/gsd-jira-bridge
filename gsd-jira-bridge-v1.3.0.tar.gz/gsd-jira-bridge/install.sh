#!/usr/bin/env bash
# =============================================================================
# gsd-jira-bridge — Installer
# Syncs GSD (get-shit-done) with Jira via MCP
#
# Run from inside your project (no manual clone needed):
#
#   Windows (PowerShell):
#   git clone https://github.com/luigiserra-org/gsd-jira-bridge.git $env:TEMP\gsd-jira-bridge; bash "$env:TEMP\gsd-jira-bridge\install.sh"; Remove-Item -Recurse -Force $env:TEMP\gsd-jira-bridge
#
#   Linux / WSL:
#   git clone https://github.com/luigiserra-org/gsd-jira-bridge.git /tmp/gsd-jira-bridge && bash /tmp/gsd-jira-bridge/install.sh && rm -rf /tmp/gsd-jira-bridge
# =============================================================================

set -euo pipefail

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }
info() { echo -e "${BLUE}→${NC} $1"; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║       gsd-jira-bridge  installer       ║${NC}"
echo -e "${BOLD}╚════════════════════════════════════════╝${NC}"
echo ""

# ── Helper: ask with default ──────────────────────────────────────────────────
ask() {
  local prompt="$1"
  local default="${2:-}"
  local answer
  if [[ -n "$default" ]]; then
    read -rp "$(echo -e "${BOLD}?${NC} ${prompt} [${default}]: ")" answer
    echo "${answer:-$default}"
  else
    read -rp "$(echo -e "${BOLD}?${NC} ${prompt}: ")" answer
    echo "$answer"
  fi
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 1 — Check prerequisites
# ═════════════════════════════════════════════════════════════════════════════
echo -e "${BOLD}[1/4] Checking prerequisites${NC}"
echo ""

ERRORS=0

# 1a. Claude Code installed?
if command -v claude &>/dev/null; then
  CLAUDE_VERSION=$(claude --version 2>/dev/null | head -1 || echo "unknown")
  ok "Claude Code found: $CLAUDE_VERSION"
else
  err "Claude Code not found. Install from: https://claude.ai/code"
  ERRORS=$((ERRORS + 1))
fi

# 1b. GSD installed? (look for commands in ~/.claude/commands/ or ./.claude/commands/)
GSD_FOUND=false
GSD_INSTALL_TYPE=""

if [[ -d "$HOME/.claude/commands" ]] && ls "$HOME/.claude/commands"/gsd* &>/dev/null 2>&1; then
  GSD_FOUND=true
  GSD_INSTALL_TYPE="global"
  GSD_COMMANDS_DIR="$HOME/.claude/commands"
elif [[ -d ".claude/commands" ]] && ls ".claude/commands"/gsd* &>/dev/null 2>&1; then
  GSD_FOUND=true
  GSD_INSTALL_TYPE="local"
  GSD_COMMANDS_DIR="./.claude/commands"
fi

if $GSD_FOUND; then
  ok "GSD found ($GSD_INSTALL_TYPE install): $GSD_COMMANDS_DIR"
else
  err "GSD not found. Install with: npx get-shit-done-cc --claude --global"
  ERRORS=$((ERRORS + 1))
fi

# 1c. Jira MCP configured?
MCP_CONFIG=""
if [[ -f "$HOME/.claude/claude_desktop_config.json" ]]; then
  MCP_CONFIG="$HOME/.claude/claude_desktop_config.json"
elif [[ -f "$HOME/.config/claude/claude_desktop_config.json" ]]; then
  MCP_CONFIG="$HOME/.config/claude/claude_desktop_config.json"
fi

JIRA_MCP_FOUND=false
if [[ -n "$MCP_CONFIG" ]]; then
  if grep -qi "jira\|atlassian" "$MCP_CONFIG" 2>/dev/null; then
    JIRA_MCP_FOUND=true
    ok "Jira MCP found in: $MCP_CONFIG"
  fi
fi

if ! $JIRA_MCP_FOUND; then
  warn "Jira MCP not detected automatically."
  echo ""
  read -rp "$(echo -e "${BOLD}?${NC} Do you have the Jira MCP configured in Claude Code? (y/n): ")" MCP_CONFIRM
  if [[ "$MCP_CONFIRM" =~ ^[Yy]$ ]]; then
    ok "Jira MCP confirmed manually"
    JIRA_MCP_FOUND=true
  else
    err "Jira MCP required. Set it up at: https://docs.claude.com/en/docs/mcp"
    ERRORS=$((ERRORS + 1))
  fi
fi

# Stop if there are critical errors
if [[ $ERRORS -gt 0 ]]; then
  echo ""
  err "$ERRORS error(s) found. Fix prerequisites and re-run the installer."
  exit 1
fi

echo ""

# ═════════════════════════════════════════════════════════════════════════════
# STEP 2 — Jira configuration
# ═════════════════════════════════════════════════════════════════════════════
echo -e "${BOLD}[2/4] Jira configuration${NC}"
echo ""
info "Find your Cloud ID at: Jira Settings → Products → Atlassian Cloud → Organization ID"
info "Find your Project Key in the Jira project URL: .../jira/software/projects/[KEY]/..."
echo ""

JIRA_CLOUD_ID=$(ask "Jira Cloud ID (UUID)")
while [[ -z "$JIRA_CLOUD_ID" ]]; do
  warn "Cloud ID is required."
  JIRA_CLOUD_ID=$(ask "Jira Cloud ID (UUID)")
done

JIRA_PROJECT_KEY=$(ask "Jira Project Key (e.g. EZY)")
JIRA_PROJECT_KEY=$(echo "$JIRA_PROJECT_KEY" | tr '[:lower:]' '[:upper:]')
while [[ -z "$JIRA_PROJECT_KEY" ]]; do
  warn "Project Key is required."
  JIRA_PROJECT_KEY=$(ask "Jira Project Key")
  JIRA_PROJECT_KEY=$(echo "$JIRA_PROJECT_KEY" | tr '[:lower:]' '[:upper:]')
done

JIRA_BASE_URL=$(ask "Jira base URL (e.g. https://yourorg.atlassian.net)")
while [[ -z "$JIRA_BASE_URL" ]]; do
  warn "Base URL is required."
  JIRA_BASE_URL=$(ask "Jira base URL")
done

echo ""

# ═════════════════════════════════════════════════════════════════════════════
# STEP 3 — Install type (global or local)
# ═════════════════════════════════════════════════════════════════════════════
echo -e "${BOLD}[3/4] Install type${NC}"
echo ""
echo "  global  → ~/.claude/commands/  (available in all projects)"
echo "  local   → ./.claude/commands/  (current project only)"
echo ""

INSTALL_TYPE=$(ask "Install type" "global")
if [[ "$INSTALL_TYPE" == "global" ]]; then
  DEST_COMMANDS="$HOME/.claude/commands"
  DEST_CONFIG="$HOME/.claude/gsd-jira-bridge.json"
else
  DEST_COMMANDS="./.claude/commands"
  DEST_CONFIG="./.claude/gsd-jira-bridge.json"
fi

mkdir -p "$DEST_COMMANDS"

echo ""

# ═════════════════════════════════════════════════════════════════════════════
# STEP 4 — Copy files and write config
# ═════════════════════════════════════════════════════════════════════════════
echo -e "${BOLD}[4/4] Installing files${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_COMMANDS="$SCRIPT_DIR/commands"

# Copy slash commands
COPIED=0
for cmd_file in "$SRC_COMMANDS"/*.md; do
  [[ -f "$cmd_file" ]] || continue
  fname=$(basename "$cmd_file")
  cp "$cmd_file" "$DEST_COMMANDS/$fname"
  ok "Installed: $DEST_COMMANDS/$fname"
  COPIED=$((COPIED + 1))
done

if [[ $COPIED -eq 0 ]]; then
  err "No command files found in $SRC_COMMANDS"
  exit 1
fi

# Write config JSON
cat > "$DEST_CONFIG" <<EOF
{
  "version": "1.0.0",
  "jira": {
    "cloud_id": "$JIRA_CLOUD_ID",
    "project_key": "$JIRA_PROJECT_KEY",
    "base_url": "$JIRA_BASE_URL"
  },
  "mapping": {
    "milestone": "version",
    "phase": "epic",
    "wave": "story",
    "task": "task"
  },
  "installed_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "install_type": "$INSTALL_TYPE"
}
EOF

ok "Config written: $DEST_CONFIG"

# ── Final summary ─────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║   gsd-jira-bridge installed! 🎉        ║${NC}"
echo -e "${BOLD}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "Available commands in Claude Code:"
echo ""
echo -e "  ${BOLD}Main workflow:${NC}"
echo -e "  /jira-init         → after /gsd:new-project"
echo -e "  /jira-sync-phase   → after /gsd:discuss-phase"
echo -e "  /jira-sync-tasks   → after /gsd:plan-phase"
echo -e "  /jira-update       → after /gsd:execute-phase"
echo -e "  /jira-close        → after /gsd:complete-milestone"
echo ""
echo -e "  ${BOLD}Utilities:${NC}"
echo -e "  /jira-status       → sync overview"
echo -e "  /jira-pull         → import untracked Jira issues into GSD"
echo -e "  /jira-annotate     → link GSD documents to Jira Issues"
echo -e "  /jira-validate     → verify installation (run this now!)"
echo -e "  /jira-repair       → repair manifest if out of sync"
echo ""
echo -e "Start with: ${BOLD}/jira-validate${NC} → then ${BOLD}/gsd:new-project${NC} → then ${BOLD}/jira-init${NC}"
echo ""
echo -e "  by Luigi Serra · github.com/luigiserra-org"
echo ""
