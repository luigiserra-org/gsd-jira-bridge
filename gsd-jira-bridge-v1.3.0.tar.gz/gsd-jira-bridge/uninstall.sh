#!/usr/bin/env bash
# =============================================================================
# gsd-jira-bridge — Uninstaller
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }

echo ""
echo -e "${BOLD}gsd-jira-bridge — Uninstaller${NC}"
echo ""

COMMANDS=(
  "jira-init.md"
  "jira-sync-phase.md"
  "jira-sync-tasks.md"
  "jira-update.md"
  "jira-close.md"
  "jira-status.md"
  "jira-pull.md"
  "jira-repair.md"
  "jira-validate.md"
  "jira-annotate.md"
)

DIRS_TO_CHECK=(
  "$HOME/.claude/commands"
  "./.claude/commands"
)

CONFIG_FILES=(
  "$HOME/.claude/gsd-jira-bridge.json"
  "./.claude/gsd-jira-bridge.json"
)

REMOVED=0

for dir in "${DIRS_TO_CHECK[@]}"; do
  for cmd in "${COMMANDS[@]}"; do
    target="$dir/$cmd"
    if [[ -f "$target" ]]; then
      rm "$target"
      ok "Removed: $target"
      REMOVED=$((REMOVED + 1))
    fi
  done
done

for cfg in "${CONFIG_FILES[@]}"; do
  if [[ -f "$cfg" ]]; then
    rm "$cfg"
    ok "Removed: $cfg"
    REMOVED=$((REMOVED + 1))
  fi
done

if [[ $REMOVED -eq 0 ]]; then
  warn "No gsd-jira-bridge files found. Was it installed?"
else
  echo ""
  ok "gsd-jira-bridge removed ($REMOVED files deleted)."
  echo ""
  echo "Note: .planning/jira-bridge/ data has been preserved."
fi
echo ""
